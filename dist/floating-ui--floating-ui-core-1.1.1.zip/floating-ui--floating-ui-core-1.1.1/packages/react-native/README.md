# @floating-ui/react-native

This is the library to use Floating UI with React Native.

export const boxSizes: string[] = ['large', 'medium', 'small', 'tiny'];
